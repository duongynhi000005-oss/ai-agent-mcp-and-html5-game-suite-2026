const EDGE_API = 'https://ai-agent-mcp-scraper-seo-security-pro.duongynhi000005.workers.dev';

document.addEventListener('DOMContentLoaded', async () => {
  const outBox = document.getElementById('outBox');
  const tierBadge = document.getElementById('tierBadge');
  const licInput = document.getElementById('licInput');
  const today = new Date().toISOString().slice(0, 10);

  const st = await chrome.storage.local.get(['pro_key', 'daily_date', 'daily_count']);
  let isPro = st.pro_key && st.pro_key.startsWith('PRO-2026-');
  let count = st.daily_date === today ? (st.daily_count || 0) : 0;

  const updateBadge = () => {
    if (isPro) {
      tierBadge.textContent = '💎 PRO UNLIMITED';
      tierBadge.style.background = '#10b981';
    } else {
      tierBadge.textContent = `FREE (${Math.max(0, 5 - count)}/5 left)`;
    }
  };
  updateBadge();

  const checkQuota = async () => {
    if (isPro) return true;
    if (count >= 5) {
      outBox.value = '⚠️ Daily Free Quota (5/5) reached! Enter your PRO-2026-... License Key below to unlock unlimited extractions.';
      return false;
    }
    count++;
    await chrome.storage.local.set({ daily_date: today, daily_count: count });
    updateBadge();
    return true;
  };

  document.getElementById('btnActivate').addEventListener('click', async () => {
    const val = (licInput.value || '').trim();
    if (val.startsWith('PRO-2026-') && val.length >= 14) {
      isPro = true;
      await chrome.storage.local.set({ pro_key: val });
      updateBadge();
      outBox.value = '✅ PRO Unlimited License Activated!';
    } else {
      outBox.value = '❌ Invalid license key format. Expected PRO-2026-XXXXXX';
    }
  });

  document.getElementById('btnMd').addEventListener('click', async () => {
    if (!(await checkQuota())) return;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) return;
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const title = document.title;
        const h = Array.from(document.querySelectorAll('h1, h2, h3')).map(el => `${'#'.repeat(Number(el.tagName[1]))} ${el.innerText.trim()}`).join('\n');
        const body = document.body.innerText.replace(/\n{3,}/g, '\n\n').trim().slice(0, 15000);
        return `# ${title}\n\nURL: ${location.href}\n\n## Headings\n${h}\n\n## Content\n${body}`;
      }
    });
    outBox.value = result;
    await navigator.clipboard.writeText(result);
  });

  document.getElementById('btnSeo').addEventListener('click', async () => {
    if (!(await checkQuota())) return;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url) return;
    outBox.value = '⏳ Auditing SEO & Security Headers via Cloudflare Edge Worker...';
    try {
      const [seoRes, secRes] = await Promise.all([
        fetch(`${EDGE_API}/v1/seo-audit?url=${encodeURIComponent(tab.url)}`).then(r => r.json()),
        fetch(`${EDGE_API}/v1/security-audit?url=${encodeURIComponent(tab.url)}`).then(r => r.json())
      ]);
      const report = JSON.stringify({ seo: seoRes, security: secRes }, null, 2);
      outBox.value = report;
      await navigator.clipboard.writeText(report);
    } catch (e) {
      outBox.value = 'Error: ' + e.message;
    }
  });
});
